"""swissfirm - firmware static analysis toolkit.

A mature rewrite of the original single-file ``firmswiss.py``.  It keeps the
original five search operations (function origin, byte patterns, mnemonic
patterns, needed libraries, function substrings) and adds a set of static
analysis passes (string extraction, security hardening audit, dangerous
import detection, crypto-constant scanning, kernel module inspection and a
filesystem inventory) plus a dependency-free ELF parser.
"""

__version__ = "2.0.0"
__all__ = [
    "__version__",
    "cli",
    "elfparse",
    "kernelmod",
    "searchers",
    "analyze",
    "report",
    "util",
]
