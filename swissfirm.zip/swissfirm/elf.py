"""ELF metadata and symbol access.

Backed by :mod:`elftools` (pyelftools, pip-installable).  Keeps the toolchain
independent of host `readelf`/`objdump` availability while still working on
cross-compiled firmware binaries.

The :class:`ElfFile` view is backend-agnostic: searchers and analyzers only
depend on this module's API.  When pyelftools is not installed a best-effort
fallback uses the classic binutils tools (``readelf``/``nm``) instead, so the
tool never hard-fails on a fresh machine.
"""

from __future__ import annotations

import os
import re
import struct
import subprocess
from dataclasses import dataclass, field
from typing import Dict, List, Optional

try:  # pragma: no cover - exercised by tests only
    from elftools.elf.elffile import ELFFile as _ELFFile
    from elftools.elf.enums import (
        ENUM_E_MACHINE,
        ENUM_E_TYPE,
        ENUM_P_TYPE_BASE,
        ENUM_SH_TYPE_BASE,
        ENUM_ST_INFO_BIND,
        ENUM_ST_INFO_TYPE,
    )

    HAS_PYELFTOOLS = True
except ImportError:  # pragma: no cover
    _ELFFile = None
    HAS_PYELFTOOLS = False
    ENUM_E_MACHINE = ENUM_E_TYPE = ENUM_P_TYPE_BASE = {}
    ENUM_SH_TYPE_BASE = ENUM_ST_INFO_BIND = ENUM_ST_INFO_TYPE = {}

# ---------------------------------------------------------------- constants
ET_REL = 1
ET_EXEC = 2
ET_DYN = 3
ET_CORE = 4

PT_LOAD = 1
PT_DYNAMIC = 2
PT_INTERP = 3
PT_GNU_STACK = 0x6474E551
PT_GNU_RELRO = 0x6474E552

SHT_NULL = 0
SHT_SYMTAB = 2
SHT_STRTAB = 3
SHT_DYNAMIC = 6
SHT_DYNSYM = 11

SHF_WRITE = 0x1
SHF_ALLOC = 0x2
SHF_EXECINSTR = 0x4

STB_LOCAL = 0
STB_GLOBAL = 1
STB_WEAK = 2
STT_NOTYPE = 0
STT_OBJECT = 1
STT_FUNC = 2
STT_GNU_IFUNC = 10

SHN_UNDEF = 0
SHN_ABS = 0xFFF1
SHN_COMMON = 0xFFF2

ET_NAMES = {
    0: "NONE",
    ET_REL: "REL (relocatable)",
    ET_EXEC: "EXEC (executable)",
    ET_DYN: "DYN (pie/shared)",
    ET_CORE: "CORE",
}

EM_NAMES = {
    3: "x86",
    62: "x86-64",
    40: "ARM",
    183: "AArch64",
    20: "PPC",
    21: "PPC64",
    8: "MIPS",
    2: "SPARC",
    43: "SPARCv9",
    243: "RISC-V",
    42: "SuperH",
    45: "ARC",
    140: "TMS320C6000",
    189: "MicroBlaze",
    258: "LoongArch",
}

_STT_TO_NM = {
    STT_NOTYPE: "n",
    STT_OBJECT: "d",
    STT_FUNC: "t",
    STT_GNU_IFUNC: "i",
}


def _enum(name: str, table: Dict[str, int]) -> int:
    if isinstance(name, int):
        return name
    return table.get(name, -1)


class ElfParseError(Exception):
    """Raised when a file cannot be interpreted as a supported ELF."""


# ---------------------------------------------------------------- dataclasses
@dataclass
class Segment:
    type: int
    flags: int
    offset: int
    vaddr: int
    paddr: int
    filesz: int
    memsz: int
    align: int


@dataclass
class Section:
    name: str
    type: int
    flags: int
    addr: int
    offset: int
    size: int
    link: int
    info: int
    align: int
    entsize: int


@dataclass
class Symbol:
    name: str
    value: int
    size: int
    bind: int
    type: int
    shndx: int
    section: str  # resolved section name (or *UNDEF* / *ABS* / *COM*)
    section_flags: int = 0
    is_undefined: bool = False

    @property
    def is_func(self) -> bool:
        return self.type in (STT_FUNC, STT_GNU_IFUNC)

    @property
    def is_defined_text(self) -> bool:
        """Defined function/ifunc symbol living in an executable section.

        The ``shndx < 0xFF00`` guard rejects the special pseudo-sections
        (*ABS*, *COM*, *UNDEF*) that a naive ``is_undefined`` check misses.
        """
        return (
            self.is_func
            and not self.is_undefined
            and self.shndx < 0xFF00
            and bool(self.section_flags & SHF_EXECINSTR)
        )

    def nm_type(self) -> str:
        base = _STT_TO_NM.get(self.type, "n")
        return base.upper() if self.bind != STB_LOCAL else base

    def type_name(self) -> str:
        return _stt_name(self.type)

    def bind_name(self) -> str:
        if self.bind == STB_GLOBAL:
            return "GLOBAL"
        if self.bind == STB_WEAK:
            return "WEAK"
        if self.bind == STB_LOCAL:
            return "LOCAL"
        return f"bind{self.bind}"


def _stt_name(t: int) -> str:
    return {
        STT_NOTYPE: "NOTYPE",
        STT_OBJECT: "OBJECT",
        STT_FUNC: "FUNC",
        STT_GNU_IFUNC: "IFUNC",
    }.get(t, f"type{t}")


@dataclass
class ElfFile:
    path: str
    elf_class: int  # 32 or 64
    endian: str  # '<' or '>'
    e_type: int
    e_machine: int
    e_flags: int
    entry: int
    segments: List[Segment] = field(default_factory=list)
    sections: List[Section] = field(default_factory=list)
    symtab: List[Symbol] = field(default_factory=list)
    dynsym: List[Symbol] = field(default_factory=list)
    needed: List[str] = field(default_factory=list)
    interp: Optional[str] = None
    bind_now: bool = False
    has_dynsym: bool = False

    # ------------------------------------------------------------- metadata
    @property
    def is_relocatable(self) -> bool:
        return self.e_type == ET_REL

    @property
    def is_shared(self) -> bool:
        return self.e_type == ET_DYN

    @property
    def is_executable(self) -> bool:
        return self.e_type == ET_EXEC

    @property
    def endianness(self) -> str:
        return "little" if self.endian == "<" else "big"

    @property
    def type_name(self) -> str:
        return ET_NAMES.get(self.e_type, f"ET_{self.e_type}")

    @property
    def machine_name(self) -> str:
        return EM_NAMES.get(self.e_machine, f"machine_{self.e_machine}")

    def has_section(self, name: str) -> bool:
        return any(s.name == name for s in self.sections)

    def get_section(self, name: str) -> Optional[Section]:
        for s in self.sections:
            if s.name == name:
                return s
        return None

    @property
    def has_modinfo(self) -> bool:
        return self.has_section(".modinfo")

    def is_kernel_module(self) -> bool:
        """True for a kernel module (relocatable object carrying .modinfo)."""
        return self.is_relocatable and self.has_modinfo

    # ---------------------------------------------------------------- symbols
    def all_symbols(self) -> List[Symbol]:
        """symtab symbols, then dynsym (deduplicated by name)."""
        out = list(self.symtab)
        seen = {s.name for s in out}
        for s in self.dynsym:
            if s.name not in seen:
                out.append(s)
                seen.add(s.name)
        return out

    def defined_functions(self) -> List[Symbol]:
        """All defined text/function symbols, sorted by (section, value)."""
        funcs = [s for s in self.symtab if s.is_defined_text]
        funcs.sort(key=lambda s: (s.shndx, s.value))
        return funcs

    def defined_dynamic_functions(self) -> List[Symbol]:
        """Exported function symbols from .dynsym (the dynamic API surface)."""
        return sorted(
            (s for s in self.dynsym if s.is_defined_text),
            key=lambda s: (s.shndx, s.value),
        )

    def undefined_symbols(self) -> List[Symbol]:
        """Imported/undefined symbols - what this binary links against."""
        return sorted(
            (s for s in self.dynsym if s.is_undefined and s.name),
            key=lambda s: (s.name.lower(), s.value),
        )

    # ------------------------------------------------------------- hardening
    def has_gnu_stack_exec(self) -> bool:
        return any(
            seg.type == PT_GNU_STACK and seg.flags & 0x1 for seg in self.segments
        )

    def has_gnu_relro(self) -> bool:
        return any(seg.type == PT_GNU_RELRO for seg in self.segments)

    def has_exec_writable_load(self) -> bool:
        """W^X violation: any PT_LOAD both writable and executable."""
        return any(
            seg.type == PT_LOAD and (seg.flags & 0x2) and (seg.flags & 0x1)
            for seg in self.segments
        )

    def has_text_relocs(self) -> bool:
        return self.has_section(".rel.text") or self.has_section(".rela.text")

    @property
    def is_stripped(self) -> bool:
        """No .symtab -> symbols were stripped (dynsym may remain)."""
        return not self.has_section(".symtab")

    def has_bind_now(self) -> bool:
        return self.has_section(".rela.plt") or self.has_section(".rel.plt")


# ---------------------------------------------------------------------------
# pyelftools backend
# ---------------------------------------------------------------------------

def _convert_sections(all_sections: List) -> List[Section]:
    out = []
    for sec in all_sections:
        hdr = sec.header
        out.append(
            Section(
                name=sec.name,
                type=_enum(hdr.get("sh_type", ""), ENUM_SH_TYPE_BASE),
                flags=hdr.get("sh_flags", 0) or 0,
                addr=hdr.get("sh_addr", 0) or 0,
                offset=hdr.get("sh_offset", 0) or 0,
                size=hdr.get("sh_size", 0) or 0,
                link=hdr.get("sh_link", 0) or 0,
                info=hdr.get("sh_info", 0) or 0,
                align=hdr.get("sh_addralign", 0) or 0,
                entsize=hdr.get("sh_entsize", 0) or 0,
            )
        )
    return out


def _convert_segments(elffile) -> List[Segment]:
    out = []
    for seg in elffile.iter_segments():
        hdr = seg.header
        out.append(
            Segment(
                type=_enum(hdr.get("p_type", ""), ENUM_P_TYPE_BASE),
                flags=hdr.get("p_flags", 0) or 0,
                offset=hdr.get("p_offset", 0) or 0,
                vaddr=hdr.get("p_vaddr", 0) or 0,
                paddr=hdr.get("p_paddr", 0) or 0,
                filesz=hdr.get("p_filesz", 0) or 0,
                memsz=hdr.get("p_memsz", 0) or 0,
                align=hdr.get("p_align", 0) or 0,
            )
        )
    return out


def _section_name_for(all_sections: List, shndx: object) -> str:
    if isinstance(shndx, str):
        return "*%s*" % shndx.replace("SHN_", "")
    if isinstance(shndx, int):
        if shndx == 0:
            return "*UNDEF*"
        if 0 < shndx < len(all_sections):
            return all_sections[shndx].name or f"*idx{shndx}*"
        return f"*idx{shndx}*"
    return f"*{shndx}*"


def _convert_symbols(all_sections: List, sec) -> List[Symbol]:
    out = []
    for sym in sec.iter_symbols():
        st_shndx = sym["st_shndx"]
        is_undef = isinstance(st_shndx, str) and st_shndx == "SHN_UNDEF"
        sec_name = _section_name_for(all_sections, st_shndx)
        shndx = st_shndx if isinstance(st_shndx, int) else 0xFFFF
        flags = 0
        if isinstance(st_shndx, int) and 0 < st_shndx < len(all_sections):
            flags = all_sections[st_shndx].header.get("sh_flags", 0) or 0
        out.append(
            Symbol(
                name=sym.name,
                value=sym["st_value"],
                size=sym["st_size"],
                bind=_enum(sym["st_info"]["bind"], ENUM_ST_INFO_BIND),
                type=_enum(sym["st_info"]["type"], ENUM_ST_INFO_TYPE),
                shndx=shndx,
                section=sec_name,
                section_flags=flags,
                is_undefined=is_undef,
            )
        )
    return out


def _pyelftools_parse(path: str, symbols: bool = True) -> ElfFile:
    with open(path, "rb") as fh:
        elffile = _ELFFile(fh)
        hdr = elffile.header
        all_sections = list(elffile.iter_sections())
        elf = ElfFile(
            path=path,
            elf_class=64 if elffile.elfclass == 64 else 32,
            endian="<" if elffile.little_endian else ">",
            e_type=_enum(hdr["e_type"], ENUM_E_TYPE),
            e_machine=_enum(hdr["e_machine"], ENUM_E_MACHINE),
            e_flags=hdr.get("e_flags", 0) or 0,
            entry=hdr.get("e_entry", 0) or 0,
            segments=_convert_segments(elffile),
            sections=_convert_sections(all_sections),
        )

        for seg in elffile.iter_segments():
            if seg["p_type"] == "PT_INTERP" and seg["p_filesz"] > 0:
                elf.interp = seg.data().split(b"\x00")[0].decode(
                    "utf-8", errors="replace"
                )
                break

        dynamic = elffile.get_section_by_name(".dynamic")
        if dynamic is not None:
            for tag in dynamic.iter_tags():
                d_tag = tag.entry.d_tag
                if d_tag == "DT_NEEDED":
                    elf.needed.append(tag.needed)
                elif d_tag == "DT_BIND_NOW":
                    elf.bind_now = True
                elif d_tag == "DT_FLAGS" and (tag.entry.d_val & 0x8):  # DF_BIND_NOW
                    elf.bind_now = True
        elf.has_dynsym = elffile.get_section_by_name(".dynsym") is not None

        if symbols:
            symtab = elffile.get_section_by_name(".symtab")
            dynsym = elffile.get_section_by_name(".dynsym")
            if symtab is not None:
                elf.symtab = _convert_symbols(all_sections, symtab)
            if dynsym is not None:
                elf.dynsym = _convert_symbols(all_sections, dynsym)
    return elf


# ---------------------------------------------------------------------------
# binutils fallback (used only when pyelftools is unavailable)
# ---------------------------------------------------------------------------

def _header_sniff(path: str) -> Dict[str, object]:
    """Minimal ELF header sniff (class/endian/type/machine) via raw bytes.

    This is *not* a full parser - just the 64-byte header - used only when
    pyelftools is missing so the tool can still classify files.
    """
    with open(path, "rb") as fh:
        raw = fh.read(64)
    if len(raw) < 20 or raw[:4] != b"\x7fELF":
        raise ElfParseError(f"{path!r} is not an ELF file")
    endian = "<" if raw[5] == 1 else ">" if raw[5] == 2 else None
    if endian is None:
        raise ElfParseError(f"{path!r}: unknown ELF data encoding {raw[5]}")
    is64 = raw[4] == 2
    if is64:
        e_type, e_machine = struct.unpack(endian + "HH", raw[16:20])
        entry = struct.unpack(endian + "Q", raw[24:32])[0]
    else:
        e_type, e_machine = struct.unpack(endian + "HH", raw[16:20])
        entry = struct.unpack(endian + "I", raw[24:28])[0]
    return {
        "is64": is64,
        "endian": endian,
        "e_type": e_type,
        "e_machine": e_machine,
        "entry": entry,
    }


def _run(*args: str) -> str:
    try:
        return subprocess.run(
            list(args), capture_output=True, text=True, check=False
        ).stdout
    except (OSError, ValueError):  # missing tool, bad invocation
        return ""


def _nm_symbols(path: str, dynamic: bool) -> List[Symbol]:
    """Best-effort symbol table via ``nm -S`` (used without pyelftools)."""
    if not _which("nm"):
        return []
    cmd = ["nm", "-S", "--defined-only"]
    if dynamic:
        cmd += ["-D"]
    out = _run(*cmd, path)
    symbols = []
    for line in out.splitlines():
        parts = line.split(None, 3)
        if len(parts) < 3:
            continue
        try:
            val = int(parts[0], 16)
        except ValueError:
            continue
        try:
            size = int(parts[1], 16)
        except ValueError:
            size = 0
        if len(parts) >= 4:
            nm_type, name = parts[2], parts[3]
        else:
            nm_type, name = parts[1], parts[2]
        bind = STB_GLOBAL if nm_type.isupper() else STB_LOCAL
        is_text = nm_type.lower() == "t"
        t = STT_FUNC if is_text else STT_NOTYPE
        symbols.append(
            Symbol(
                name=name,
                value=val,
                size=size,
                bind=bind,
                type=t,
                shndx=1,
                section="*text*" if is_text else "*data*",
                section_flags=SHF_EXECINSTR if is_text else 0,
                is_undefined=False,
            )
        )
    return symbols


def _which(tool: str) -> bool:
    try:
        return subprocess.run(
            ["which", tool], capture_output=True, text=True, check=False
        ).returncode == 0
    except OSError:
        return False


def _binutils_parse(path: str, symbols: bool = True) -> ElfFile:
    info = _header_sniff(path)
    elf = ElfFile(
        path=path,
        elf_class=64 if info["is64"] else 32,
        endian=info["endian"],
        e_type=info["e_type"],
        e_machine=info["e_machine"],
        e_flags=0,
        entry=info["entry"],
    )
    if _which("readelf"):
        rd = _run("readelf", "-d", path)
        for m in re.findall(r"\(NEEDED\)\s+Shared library:\s+\[([^\]]+)\]", rd):
            elf.needed.append(m)
    if symbols:
        elf.symtab = _nm_symbols(path, dynamic=False)
        elf.dynsym = _nm_symbols(path, dynamic=True)
    return elf


# ---------------------------------------------------------------------------
# public entry point
# ---------------------------------------------------------------------------

def parse_elf(path: str, symbols: bool = True) -> ElfFile:
    """Parse *path* into an :class:`ElfFile`.

    Uses pyelftools when available and falls back to binutils otherwise.
    Raises :class:`ElfParseError` for non-ELF or unreadable files.
    """
    if not os.path.isfile(path):
        raise ElfParseError(f"{path!r} is not a regular file")
    if HAS_PYELFTOOLS:
        try:
            return _pyelftools_parse(path, symbols=symbols)
        except Exception as exc:  # noqa: BLE001
            raise ElfParseError(f"failed to parse {path!r}: {exc}") from exc
    return _binutils_parse(path, symbols=symbols)
