"""Symbol display/analysis helpers shared by searchers and analyzers.

Kernel modules (``.ko``) are ``ET_REL`` objects, which makes their *symbol
printing* trickier than normal executables:

* symbol ``value`` is an *offset inside a section*, not a virtual address;
* ARM/AArch64 modules carry mapping symbols (``$a``, ``$t``, ``$x``...);
* GCC emits ``name.isra.0``, ``name.constprop.1``, ``name.part.0`` variants;
* local ``.L*`` labels and anonymous symbols are pure noise for a search.

The helpers below normalise all of that so callers get a clean, consistent
view regardless of ELF type.
"""

from __future__ import annotations

import re
from typing import List

from .elf import ET_EXEC, ET_DYN, ET_REL, Symbol, ElfFile

_MAPPING_PREFIX = ("$a", "$t", "$x", "$p", "$c", "$d", "$m", "$v")
_GCC_SUFFIXES = ("isra", "constprop", "part", "cfi", "cold", "lto_priv", "eh")
_NOISE_NAMES = {
    "_GLOBAL_OFFSET_TABLE_",
    "_PROCEDURE_LINKAGE_TABLE_",
    "__dso_handle",
    "_DYNAMIC",
    "_init",
    "_fini",
    "__init_array_start",
    "__init_array_end",
    "__fini_array_start",
    "__fini_array_end",
    "__preinit_array_start",
    "__preinit_array_end",
    "__bss_start",
    "_edata",
    "_end",
    "__data_start",
    "__etext",
    "_etext",
    "__executable_start",
    "__GNU_EH_FRAME_HDR",
    "__frame_dummy_init_array_entry",
    "__FRAME_END__",
    "frame_dummy",
    "__gnu_local_gp",
    "_gp",
    "KERNEL_SYSCTL_TABLE",
    "__ksymtab_strings",
    "__versions",
    "__this_module",
    "this_module",
    "__modver_attr",
    "__mod_device_table",
}


def is_mapping_symbol(name: str) -> bool:
    """ARM/AArch64 mapping symbols like ``$a`` / ``$t`` / ``$x`` / ``$d.any``."""
    return name.startswith(_MAPPING_PREFIX)


def is_noise_symbol(name: str) -> bool:
    """Symbols that never represent a real function for search purposes."""
    if not name:
        return True
    if name.startswith("$"):
        return True
    if name.startswith(".L"):
        return True
    if name.startswith("__gnu_lto"):
        return True
    if name in _NOISE_NAMES:
        return True
    return False


def gcc_base(name: str) -> str:
    """Strip GCC clone suffixes: ``foo.isra.3`` -> ``foo``, ``foo.0`` -> ``foo``."""
    parts = name.split(".")
    while len(parts) > 1:
        tail = parts[-1]
        if tail.isdigit() or tail in _GCC_SUFFIXES:
            parts.pop()
            continue
        break
    return ".".join(parts)


def versionless(name: str) -> str:
    """Strip ELF version suffixes: ``foo@GLIBC_2.2.5`` / ``foo@@GLIBC_2.2.5``."""
    if "@" in name:
        return name.split("@", 1)[0]
    return name


def iter_function_symbols(elf: ElfFile) -> List[Symbol]:
    """Defined function symbols, minus mapping / noise / empty names."""
    return [s for s in elf.defined_functions() if not is_noise_symbol(s.name)]


def human_address(elf: ElfFile, sym: Symbol) -> str:
    """Render a symbol's location sensibly for the ELF type.

    For relocatable objects (kernel modules, ``*.o``) an absolute address is
    meaningless - the value is an offset inside a section - so we show
    ``section+0x..``.  For linked images we show the virtual address.
    """
    if elf.is_relocatable:
        return f"{sym.section or '?'}+0x{sym.value:x}"
    return f"0x{sym.value:x}"


def nm_letter(sym: Symbol) -> str:
    return sym.nm_type()


def parse_modinfo_key(key: str) -> str:
    return key


_VERSION_RE = re.compile(r"Linux version ([0-9]+\.[0-9]+(?:\.[0-9]+)?)")


def find_kernel_version(strings: List[str]) -> List[str]:
    """Extract ``Linux version x.y.z`` strings (e.g. from /proc/version)."""
    versions = []
    for text in strings:
        m = _VERSION_RE.search(text)
        if m and m.group(1) not in versions:
            versions.append(m.group(1))
    return versions


def importable_symbols(elf: ElfFile) -> List[Symbol]:
    """Symbols available for cross-binary lookup: defined functions and, for
    shared/executable images, the exported dynamic API."""
    out = list(iter_function_symbols(elf))
    if not elf.is_relocatable:
        for s in elf.defined_dynamic_functions():
            if not is_noise_symbol(s.name) and s.name not in {x.name for x in out}:
                out.append(s)
    return out
